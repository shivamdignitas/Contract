 <?php 

    error_reporting(0);

    $host_url = "http://localhost/contract/"; // "/" at the last in necessary
    $base_api_url = $host_url . "api/";

?>