<div class="container-fluid">
                <nav class="pull-left">
                </nav>
                <div class="copyright pull-right">
                    &copy; <script>document.write(new Date().getFullYear())</script> by <a href="http://www.dignitasdigital.com/">Dignitas Digital</a>
                </div>
            </div>