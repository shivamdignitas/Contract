<?php
//include 'api/common/common.php';
    if (isset($_POST["forgotPass"])) {
        $connection = new mysqli("localhost", "root", "", "ccsqadig_testdb");
        
        //$email = $connection->real_escape_string($_POST["email"]);
        $email = stripslashes($_POST["email"]); 
        $email = mysqli_real_escape_string($connection,$_POST["email"]);
        
        //$data = $connection->query("SELECT id FROM dd_login WHERE username='".$email."'");
        $query = "SELECT id FROM dd_login WHERE username='".$email."'";
        $data = mysqli_query($connection,$query);

        if ($data->num_rows > 0) {
            $str = "0123456789qwertzuioplkjhgfdsayxcvbnm";
            $str = str_shuffle($str);
            $str = substr($str, 0, 10);
            $url = "http://localhost/contract/resetPassword.php?token=$str&email=$email";

            //mail($email, "Reset password", "To reset your password, please visit this: $url", "From: myanotheremail@domain.com\r\n");

            //$connection->query("UPDATE dd_login SET token='$str', expire = DATE_ADD(NOW(), INTERVAL 5 MINUTE) WHERE username='$email'");
            $query = "UPDATE dd_login SET token='".$str."', expire = DATE_ADD(NOW(), INTERVAL 5 MINUTE) WHERE username='".$email."'";
            $result = mysqli_query($connection,$query);

            echo "Please check your email!";
        } else {
            echo "Please check your inputs!";
        }
    }
?>
<html>
    <body>
        <form action="forgotPassword.php" method="post">
            <input type="text" name="email" placeholder="Email"><br>
            <input type="submit" name="forgotPass" value="Request Password">
        </form>
    </body>
</html>