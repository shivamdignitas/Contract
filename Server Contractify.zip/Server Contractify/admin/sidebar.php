        <div class="sidebar-wrapper">
            <div class="logo"><a href="#"><img src="../images/logo.png"></a></div>

            <ul class="nav">
                <li>
                    <a href="dashboard.php">
                        <i class="ti-panel"></i>
                        <p>Dashboard</p>
                    </a>
                </li>
                <li>
                    <a href="create.php">
                        <i class="ti-pencil-alt"></i>
                        <p>Create Contract</p>
                    </a>
                </li>
                <li>
                    <a href="upload.php">
                        <i class="ti-cloud-up"></i>
                        <p>Upload</p>
                    </a>
                </li>
                <li>
                    <a href="services.php">
                        <i class="ti-check-box"></i>
                        <p>Select Services</p>
                    </a>
                </li>
                <li>
                    <a href="addeditservices.php">
                        <i class="ti-panel"></i>
                        <p>Add/Edit Service</p>
                    </a>
                </li>
                <li>
                    <a href="history.php">
                        <i class="ti-bookmark-alt"></i>
                        <p>Contract History</p>
                    </a>
                </li>
                <li>
                    <a href="../index.php" id = "link_logout">
                        <i class="ti-power-off"></i>
                        <p>Logout</p>
                    </a>
                </li>
            </ul>
        </div>